getal = input("Geef een getal: ")

if int(getal) < 0:
    print("Het getal is negatief")
if int(getal) < 100:
    print("Het getal is kleiner dan 100")
if int(getal) >= 100:
    print("Het getal is groter of gelijk aan 100")  