#Ask for 3 numbers
getalA = input("Geef het eerste getal: ")
getalB = input("Geef het tweede getal: ")
getalC = input("Geef het derde getal: ")

#Put the numbers in a list
list1 = [getalA, getalB, getalC]

#Print the smallest number in the list
print("Het kleinste nummer is:", min(list1))