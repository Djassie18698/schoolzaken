print('Wat is het eerste getal')
getal1 = int(input())
print('Wat is het tweede getal')
getal2 = int(input())
som = getal1+getal2
verschil = getal1-getal2
product = getal1*getal2
deling = getal1/getal2
macht= pow(getal1,getal2)
print('De som van' ,getal1, 'en' ,getal2, 'is' ,som,)
print('Het verschil tussen' ,getal1, 'en' ,getal2, 'is' ,verschil)
print(product, 'is de vermenigvuldiging van' ,getal1, 'en' ,getal2)
print('Als je' ,getal1, 'deelt door' ,getal2, 'krijg je' ,deling)
print('De uitkomst van' ,getal1, '^' ,getal2, 'is' ,macht,)