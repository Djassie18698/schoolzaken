print('Wat is jouw naam?')
naam = input()
print('Welkom' ,naam,  'bij de module Scripting.')

#werkt dit?