var1 = 42
var2 = 12 - 3.0
var3 = 99 - 101 + 123
var4 = var1 < var3
var5 = "Hello World"
var6 = True
var7 = not(var4)
var8 = 9 // 2
var9 = "1234"
var10 = int(var9)

print("Var 1 heeft een waarde van ", var1, "en is van het type", type(var1))
print("Var 2 heeft een waarde van ", var2, "en is van het type", type(var2))
print("Var 3 heeft een waarde van ", var3, "en is van het type", type(var3))
print("Var 4 heeft een waarde van ", var4, "en is van het type", type(var4))
print("Var 5 heeft een waarde van ", var5, "en is van het type", type(var5))
print("Var 6 heeft een waarde van ", var6, "en is van het type", type(var6))
print("Var 7 heeft een waarde van ", var7, "en is van het type", type(var7))
print("Var 8 heeft een waarde van ", var8, "en is van het type", type(var8))
print("Var 9 heeft een waarde van ", var9, "en is van het type", type(var9))
print("Var 10 heeft een waarde van ", var10, "en is van het type", type(var10))
