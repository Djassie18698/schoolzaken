woord = input("Welk woord kies je?\n")
hoevaak = int(input("Hoevaak moet het woord getoond worden?\n"))
print((woord + ' X ') * hoevaak) 