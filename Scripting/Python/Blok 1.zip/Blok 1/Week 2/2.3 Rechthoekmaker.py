lang = int(input("Hoe lang moet de rechthoek worden?\n"))
rij = int(input("Hoeveel rijen wil je dat de rechthoek wordt?\n"))
symbool = lang * "#"

i = 0
while i < rij:
    print(symbool)
    i += 1
    